import serial
import struct

serial_port = '/dev/ttyACM0'
baud_rate = 115200

ser = serial.Serial(serial_port, baud_rate)

while True:
    data = ser.read(16)

    hex_data = data.hex()
    print("Received data (hex): ", hex_data)

    speed = struct.unpack('<f', bytes.fromhex(hex_data[0:8]))[0] 
    ak809_state_v_int = struct.unpack('<h', bytes.fromhex(hex_data[8:12]))[0] 
    torque_value = struct.unpack('<h', bytes.fromhex(hex_data[12:16]))[0] 
    current_value = struct.unpack('<h', bytes.fromhex(hex_data[16:20]))[0] 
    torque = struct.unpack('<f', bytes.fromhex(hex_data[20:28]))[0] 
    ak809_state_c_int = struct.unpack('<h', bytes.fromhex(hex_data[28:32]))[0] 

    # Print the interpreted values 
    print("speed:", speed) 
    print("ak809_state.v_int:", ak809_state_v_int) 
    print("torque_value:", torque_value) 
    print("current_value:", current_value) 
    print("torque:", torque) 
    print("ak809_state.c_int:", ak809_state_c_int) 
    print("---")
