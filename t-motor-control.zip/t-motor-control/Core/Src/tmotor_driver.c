/*
 * tmotor_driver.c
 *
 *  Created on: Jan 28, 2024
 *      Author: xuzhekai
 */


#include "tmotor_driver.h"

void CAN_Transmit_eid(uint32_t id, const uint8_t* data, uint8_t len, uint32_t *TxMailbox){
	uint8_t i = 0;
	if(len >8){
		len = 8;
	}
	CAN_TxHeaderTypeDef TxHeader;
	TxHeader.StdId = 0;
	TxHeader.IDE = CAN_ID_EXT;
	TxHeader.ExtId = id;
	TxHeader.RTR = CAN_RTR_DATA;
	TxHeader.DLC = len;

	HAL_CAN_AddTxMessage(&hcan1, &TxHeader, data, TxMailbox);
}

void buffer_append_int32(uint8_t* buffer, int32_t number, int32_t* index){
	buffer[(*index) ++] = number >> 24 & 0xFF;
	buffer[(*index) ++] = number >> 16& 0xFF;
	buffer[(*index) ++] = number >> 8& 0xFF;
	buffer[(*index) ++] = number& 0xFF;

}

void buffer_append_int16(uint8_t* buffer, int16_t number, int16_t * index){
	buffer[(*index)++] = number >> 8& 0xFF;
	buffer[(*index ) ++] = number& 0xFF;

}

void CAN_Set_Velocity(uint8_t controller_id, float rpm, uint32_t* TxMailbox){
	int32_t send_index = 0;
	uint8_t buffer[4];
	buffer_append_int32(buffer, (int32_t)rpm, &send_index);
	CAN_Transmit_eid(controller_id | ((uint32_t) CAN_PACKET_SET_RPM << 8), buffer, send_index, TxMailbox);
	// CAN_Transmit_eid(0x0000296C, buffer, send_index, TxMailbox);
}

void CAN_Set_Current(uint8_t controller_id, float current, uint32_t* TxMailbox){
	int32_t send_index = 0;
	uint8_t buffer[4];
	buffer_append_int32(buffer, (int32_t)(current * 1000.0), &send_index);
	CAN_Transmit_eid(controller_id | ((uint32_t)CAN_PACKET_SET_CURRENT << 8), buffer, send_index, TxMailbox);
}

int float_to_uint(float x, float x_min, float x_max, unsigned int bits){
	/// Converts a float to an unsigned int, given range and number of bits ///
	float span = x_max - x_min;
	if(x < x_min) x = x_min;
	else if(x > x_max) x = x_max;
	return (int) ((x- x_min)*((float)((1<<bits)/span)));
}

float uint_to_float(int x_int, float x_min, float x_max, int bits){
	/// converts unsigned int to float, given range and number of bits ///
	float span = x_max - x_min;
	float offset = x_min;
	return ((float)x_int)*span/((float)((1<<bits)-1)) + offset;
}

void motor_receive(motor_state_t* recv,
				   uint8_t rx_message[8]){
	int16_t pos_int = rx_message[0] << 8 | rx_message[1];
	int16_t spd_int = rx_message[2] << 8 | rx_message[3];
	int16_t cur_int = rx_message[4] << 8 | rx_message[5];
	recv->position= (float)( pos_int * 0.1f); //motor position
	recv->velocity= (float)( spd_int * 10.0f);//motor speed
	recv->torque = (float) ( cur_int * 0.01f);//motor current
	recv->temperature= rx_message[6];//motor temperature
	recv->error= rx_message[7];//motor error mode
	recv->v_int = spd_int;
	recv->c_int = cur_int;
	
}

//void unpack_reply(uint8_t data[8]){
//	/// unpack ints from can buffer ///
//	int id = data[0]; //Driver ID
//	int p_int = (data[1]<<8)|data[2]; // Motor Position Data
//	int v_int = (data[3]<<4)|(data[4]>>4); // Motor Speed Data
//	int i_int = ((data[4]&0xF)<<8)|data[5]; //Motor Torque Data
//	int T_int = data[6];
//	/// convert ints to floats ///
//	float p = uint_to_float(p_int, P_MIN, P_MAX, 16);
//	float v = uint_to_float(v_int, V_MIN, V_MAX, 12);
//	float i = uint_to_float(i_int, -T_MIN, T_MAX, 12);
//	float T =T_int;
//	if(id == 1){
//		motor_state.position = p; // Read corresponding data based on ID
//		motor_state.velocity = v;
//		motor_state.torque = i;
//		motor_state.temperature = T - 40; // Temperature range: -40~215
//	}
//}

void pack_cmd(uint8_t data[8], float p_des, float v_des, float kp, float kd, float t_ff){
	/// limit data to be within bounds ///
	float Kp_MIN =0;
	float Kp_MAX =500.0f;
	float Kd_MIN =0;
	float Kd_MAX =5.0f;

	p_des = fminf(fmaxf(P_MIN, p_des), P_MAX);
	v_des = fminf(fmaxf(V_MIN, v_des), V_MAX);
	kp = fminf(fmaxf(Kp_MIN, kp), Kp_MAX);
	kd = fminf(fmaxf(Kd_MIN, kd), Kd_MAX);
	t_ff = fminf(fmaxf(T_MIN, t_ff), T_MAX);

	/// convert floats to unsigned ints ///
	int p_int = float_to_uint(p_des, P_MIN, P_MAX, 16);
	int v_int = float_to_uint(v_des, V_MIN, V_MAX, 12);
	int kp_int = float_to_uint(kp, Kp_MIN, Kp_MAX, 12);
	int kd_int = float_to_uint(kd, Kd_MIN, Kd_MAX, 12);
	int t_int = float_to_uint(t_ff, T_MIN, T_MAX, 12);

	/// pack ints into the can buffer ///
	data[0] = p_int>>8; // Position High 8
	data[1] = p_int&0xFF; // Position Low 8
	data[2] = v_int>>4; // Speed High 8 bits
	data[3] = ((v_int&0xF)<<4)|(kp_int>>8); // Speed Low 4 bits KP High 4 bits
	data[4] = kp_int&0xFF; // KP Low 8 bits
	data[5] = kd_int>>4; // Kd High 8 bits
	data[6] = ((kd_int&0xF)<<4)|(t_int>>8); // KP Low 4 bits Torque High 4 bits
	data[7] = t_int&0xff; // Torque Low 8 bits
}
