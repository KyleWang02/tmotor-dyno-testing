/*
 * ADS1115.h
 *
 *  Created on: Nov 2, 2023
 *      Author: xuzhekai
 */

#ifndef INC_ADS1115_H_
#define INC_ADS1115_H_

#include "main.h"


#define ADS1115_ADDR 0x49

extern I2C_HandleTypeDef hi2c1;

extern UART_HandleTypeDef huart4;
extern UART_HandleTypeDef huart1;

enum {TORQUE, CURRENT};
int16_t get_ADC(int target);

void ADC_init();

#endif /* INC_ADS1115_H_ */
