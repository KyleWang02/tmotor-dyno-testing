#ifndef WIRELESS_H
#define WIRELESS_H

#include "main.h"

typedef enum {false, true} bool;

typedef struct{
    uint16_t x1_val;
    uint16_t y1_val;
    uint16_t x2_val;
    uint16_t y2_val;
    bool b1;
    bool b2;
    bool b3;
    bool b4;

}ESP_packet_t ;

// void decode_wireless_packet(uint8_t* packet, )

#endif //WIRELESS_H